// API Base URL - Change this based on your backend URL
const API_BASE_URL = 'http://localhost:5000';

// DOM Elements
const payslipForm = document.getElementById('payslipForm');
const contractSelect = document.getElementById('contract');
const monthSelect = document.getElementById('month');
const yearSelect = document.getElementById('year');
const employeeIdInput = document.getElementById('employeeId');
const errorMessage = document.getElementById('errorMessage');
const loadingSpinner = document.getElementById('loadingSpinner');
const payslipDisplay = document.getElementById('payslipDisplay');

// Form Submission
payslipForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    await searchPayslip();
});

// Search Payslip Function
async function searchPayslip() {
    const contract = contractSelect.value;
    const month = monthSelect.value;
    const year = yearSelect.value;
    const employeeId = employeeIdInput.value.trim();

    // Clear previous errors
    clearError();

    // Validation
    if (!contract || !month || !year || !employeeId) {
        showError('Please fill in all fields');
        return;
    }

    // Show loading spinner
    loadingSpinner.classList.remove('hidden');

    try {
        const response = await fetch(`${API_BASE_URL}/search-payslip`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
            params: {
                employee_id: employeeId,
                month: month,
                year: year,
                contract: contract
            }
        });

        // For GET requests, append params to URL
        const params = new URLSearchParams({
            employee_id: employeeId,
            month: month,
            year: year,
            contract: contract
        });

        const finalResponse = await fetch(`${API_BASE_URL}/search-payslip?${params}`);

        if (!finalResponse.ok) {
            throw new Error('Failed to fetch payslip');
        }

        const data = await finalResponse.json();

        if (data.success) {
            displayPayslip(data.payslip);
        } else {
            showError(data.message || 'Payslip not found');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error fetching payslip: ' + error.message);
    } finally {
        loadingSpinner.classList.add('hidden');
    }
}

// Display Payslip
function displayPayslip(payslip) {
    document.getElementById('slipEmployeeName').textContent = payslip.employee_name || '-';
    document.getElementById('slipEmployeeId').textContent = payslip.employee_id || '-';
    document.getElementById('slipMonthYear').textContent = `${payslip.month}, ${payslip.year}`;

    document.getElementById('slipBasicSalary').textContent = formatCurrency(payslip.basic_salary);
    document.getElementById('slipHRA').textContent = formatCurrency(payslip.hra);
    document.getElementById('slipAllowances').textContent = formatCurrency(payslip.allowances);
    document.getElementById('slipDeductions').textContent = formatCurrency(payslip.deductions);
    document.getElementById('slipNetSalary').textContent = formatCurrency(payslip.net_salary);

    // Store payslip data for PDF download
    window.currentPayslip = payslip;

    // Show payslip display
    payslipDisplay.classList.remove('hidden');

    // Scroll to payslip
    payslipDisplay.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Close Payslip Display
function closePayslip() {
    payslipDisplay.classList.add('hidden');
    window.currentPayslip = null;
}

// Show Error Message
function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.add('show');
}

// Clear Error Message
function clearError() {
    errorMessage.textContent = '';
    errorMessage.classList.remove('show');
}

// Format Currency
function formatCurrency(value) {
    if (!value || isNaN(value)) return '₹ 0';
    return '₹ ' + parseFloat(value).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Download Payslip as PDF
async function downloadPayslipPDF() {
    if (!window.currentPayslip) {
        showError('No payslip data available');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/generate-payslip-pdf`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(window.currentPayslip)
        });

        if (!response.ok) {
            throw new Error('Failed to generate PDF');
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `Payslip_${window.currentPayslip.employee_id}_${window.currentPayslip.month}_${window.currentPayslip.year}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
    } catch (error) {
        console.error('Error:', error);
        showError('Error downloading PDF: ' + error.message);
    }
}
